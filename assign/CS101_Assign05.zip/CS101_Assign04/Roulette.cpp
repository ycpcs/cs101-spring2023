// CS101 Assignment 4 - Fall 2018
#include <stdio.h>

// TODO: Add function prototypes here

int main() {
	// TODO: Add code

	return 0;
}

// TODO: Add function definitions here